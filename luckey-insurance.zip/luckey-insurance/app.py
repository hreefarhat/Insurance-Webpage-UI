from flask import Flask, send_file
from flask import request
import json
from json2html import *


app = Flask(__name__)
app.debug = True

customers = []

@app.route('/', methods=['GET'])
def welcome_page():
    return send_file('html/welcome.htm')

@app.route('/customer_information')
def customer_information_page():
    return send_file('html/customer_information.htm')

@app.route('/add_customer', methods=['POST'])
def add_customer_api():
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    phone_number = request.form['phone_number']
    email = request.form['email']
    address = request.form['address']
    city = request.form['city']
    state = request.form['state']
    postal_code = request.form['postal_code']
    car_model = request.form['car_model']
    claim = request.form['claim']

    customer = {
        'first_name': first_name,
        'last_name': last_name,
        'phone_number': phone_number,
        'email': email,
        'address': address,
        'city': city,
        'state': state,
        'postal_code': postal_code,
        'car_model': car_model,
        'claim': claim
    }

    customers.append(customer)

    with open('customers.json', 'w+', encoding='utf-8') as f:
        json.dump({'customers':customers}, f, ensure_ascii=False, indent=4)

    return send_file('html/thank_you.htm')

@app.route('/get_customers', methods=['GET'])
def get_customers():
    global customers
    with open('customers.json', encoding='utf-8') as customer_file:
        data = customer_file.read()
        print(data)
        if data:
            customers = json.loads(data)['customers']
            print("found customers")
            print(customers)
        if customers:
            return json2html.convert(json=customers)
        else:
            return send_file('html/no_claims_found.htm')



app.run(port=5000)
